<?php
/**
 *
 * - group
 * - items
 *  - delta + field_name + value render_array or null if empty
 */
?>
<div class="field-group-multiple-table">
   <?php print $table; ?>
</div>